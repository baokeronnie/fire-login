var firebaseConfig = {
    apiKey: "AIzaSyCDL3U26Kvu16VxUcpsRtpL07dEIDwIgpQ",
    authDomain: "fir-project-a7458.firebaseapp.com",
    projectId: "fir-project-a7458",
    storageBucket: "fir-project-a7458.appspot.com",
    messagingSenderId: "575906290952",
    appId: "1:575906290952:web:0f2f7421abffc0db1420bd",
    measurementId: "G-6EF9ND3KRX"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();